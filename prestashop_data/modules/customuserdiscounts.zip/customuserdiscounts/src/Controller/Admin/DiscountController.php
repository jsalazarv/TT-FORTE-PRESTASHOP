<?php
/**
 * 2025 Juan Salazar
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 */

declare(strict_types=1);

namespace PrestaShop\Module\CustomUserDiscounts\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use PrestaShopBundle\Security\Annotation\AdminSecurity;
use PrestaShopBundle\Security\Annotation\ModuleActivated;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use PrestaShop\Module\CustomUserDiscounts\Repository\CustomUserDiscountRepository;
use Symfony\Contracts\Translation\TranslatorInterface;
use Context;
use Currency;
use Tools;
use DbQuery;
use Db;

/**
 * Controlador para gestionar los descuentos personalizados de usuarios
 */
class DiscountController extends FrameworkBundleAdminController
{
    private $discountRepository;
    private $module;
    private $translator;

    public function __construct(
        CustomUserDiscountRepository $discountRepository,
        TranslatorInterface $translator
    ) {
        $this->discountRepository = $discountRepository;
        $this->translator = $translator;
        $this->module = \Module::getInstanceByName('customuserdiscounts');
    }

    /**
     * Muestra la lista de descuentos
     *
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     * @ModuleActivated(moduleName="customuserdiscounts", redirectRoute="admin_module_manage")
     *
     * @return Response
     */
    public function listAction(): Response
    {
        // Obtener descuentos directamente usando Db
        $query = new DbQuery();
        $query->select('d.*, c.firstname, c.lastname')
              ->from('custom_user_discount', 'd')
              ->leftJoin('customer', 'c', 'c.id_customer = d.id_customer')
              ->where('d.active = 1') // Solo mostrar descuentos activos
              ->orderBy('d.date_add DESC');

        $result = Db::getInstance()->executeS($query);
        
        // Formatear los datos
        $discounts = [];
        foreach ($result as $row) {
            $discounts[] = [
                'id_custom_user_discount' => (int)$row['id_custom_user_discount'],
                'id_customer' => (int)$row['id_customer'],
                'customer_firstname' => $row['firstname'],
                'customer_lastname' => $row['lastname'],
                'discount_type' => $row['discount_type'],
                'discount_value' => (float)$row['discount_value'],
                'date_add' => $row['date_add'],
                'active' => (bool)$row['active']
            ];
        }

        // Obtener el contexto y la moneda
        $context = Context::getContext();
        $currency = new Currency($context->currency->id);

        // Renderizar usando el layout de administración
        return $this->render('@Modules/customuserdiscounts/views/templates/admin/list.html.twig', [
            'enableSidebar' => true,
            'layoutTitle' => $this->translator->trans('Customer Discounts', [], 'Modules.Customuserdiscounts.Admin'),
            'layoutHeaderToolbarBtn' => [
                'add' => [
                    'href' => '#',
                    'desc' => $this->translator->trans('Add new discount', [], 'Modules.Customuserdiscounts.Admin'),
                    'icon' => 'add_circle_outline',
                    'class' => 'btn-primary js-add-discount',
                ],
            ],
            'discounts' => $discounts,
            'currency' => $currency,
            'help_link' => false,
            'show_page_header_toolbar' => true,
        ]);
    }

    /**
     * Elimina un descuento
     *
     * @AdminSecurity("is_granted('delete', request.get('_legacy_controller'))")
     * @ModuleActivated(moduleName="customuserdiscounts", redirectRoute="admin_module_manage")
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function deleteAction(Request $request): JsonResponse
    {
        if (!$this->isCsrfTokenValid('delete_discount', $request->request->get('_token'))) {
            return new JsonResponse([
                'success' => false,
                'message' => $this->translator->trans('Invalid CSRF token', [], 'Modules.Customuserdiscounts.Admin')
            ], 403);
        }

        $discountId = (int) $request->request->get('id_discount');

        if (!$discountId) {
            return new JsonResponse([
                'success' => false,
                'message' => $this->translator->trans('Invalid discount ID', [], 'Modules.Customuserdiscounts.Admin')
            ], 400);
        }

        try {
            $result = $this->discountRepository->delete($discountId);

            return new JsonResponse([
                'success' => $result,
                'message' => $result
                    ? $this->translator->trans('Discount successfully deleted', [], 'Modules.Customuserdiscounts.Admin')
                    : $this->translator->trans('Error deleting discount', [], 'Modules.Customuserdiscounts.Admin')
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'message' => $this->translator->trans('Error deleting discount', [], 'Modules.Customuserdiscounts.Admin')
            ], 500);
        }
    }

    /**
     * Actualiza un descuento existente
     *
     * @AdminSecurity("is_granted('update', request.get('_legacy_controller'))")
     * @ModuleActivated(moduleName="customuserdiscounts", redirectRoute="admin_module_manage")
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function updateAction(Request $request): JsonResponse
    {
        if (!$this->isCsrfTokenValid('update_discount', $request->request->get('_token'))) {
            return new JsonResponse([
                'success' => false,
                'message' => $this->translator->trans('Invalid CSRF token', [], 'Modules.Customuserdiscounts.Admin')
            ], 403);
        }

        $discountId = (int) $request->request->get('id_discount');
        $discountType = $request->request->get('discount_type');
        $discountValue = (float) $request->request->get('discount_value');

        if (!$discountId || !$discountType || $discountValue < 0) {
            return new JsonResponse([
                'success' => false,
                'message' => $this->translator->trans('Invalid discount data', [], 'Modules.Customuserdiscounts.Admin')
            ], 400);
        }

        try {
            $result = $this->discountRepository->update($discountId, [
                'discount_type' => $discountType,
                'discount_value' => $discountValue,
                'date_upd' => date('Y-m-d H:i:s')
            ]);

            return new JsonResponse([
                'success' => $result,
                'message' => $result
                    ? $this->translator->trans('Discount successfully updated', [], 'Modules.Customuserdiscounts.Admin')
                    : $this->translator->trans('Error updating discount', [], 'Modules.Customuserdiscounts.Admin')
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'message' => $this->translator->trans('Error updating discount', [], 'Modules.Customuserdiscounts.Admin')
            ], 500);
        }
    }
}
