<?php

namespace CustomUserDiscounts\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\FormFactoryInterface;
use PrestaShop\PrestaShop\Core\Hook\HookDispatcher;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Contracts\Translation\TranslatorInterface;
use PrestaShop\PrestaShop\Adapter\LegacyContext;

class ConfigurationController extends FrameworkBundleAdminController
{
    private $formFactory;
    private $hookDispatcher;
    private $router;
    private $translator;
    private $legacyContext;

    public function __construct(
        FormFactoryInterface $formFactory,
        HookDispatcher $hookDispatcher,
        RouterInterface $router,
        TranslatorInterface $translator,
        LegacyContext $legacyContext
    ) {
        parent::__construct();
        $this->formFactory = $formFactory;
        $this->hookDispatcher = $hookDispatcher;
        $this->router = $router;
        $this->translator = $translator;
        $this->legacyContext = $legacyContext;
    }

    public function indexAction(Request $request): Response
    {
        $formHandler = $this->get('custom_user_discounts.form.configuration_form_handler');
        $form = $formHandler->getForm();

        return $this->render('@Modules/customuserdiscounts/views/templates/admin/configure.html.twig', [
            'configurationForm' => $form->createView(),
            'help_link' => false,
            'enableSidebar' => true,
            'layoutTitle' => $this->translator->trans('Configuración de Descuentos Personalizados', [], 'Modules.Customuserdiscounts.Admin'),
        ]);
    }

    public function saveAction(Request $request): Response
    {
        $formHandler = $this->get('custom_user_discounts.form.configuration_form_handler');
        $form = $formHandler->getForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $data = $form->getData();
            
            \Configuration::updateValue('CUSTOM_USER_DISCOUNTS_ENABLED', $data['enabled']);
            \Configuration::updateValue('CUSTOM_USER_DISCOUNTS_APPLY_TO', $data['apply_to']);
            \Configuration::updateValue('CUSTOM_USER_DISCOUNTS_CATEGORIES', json_encode($data['categories']));

            $this->addFlash(
                'success',
                $this->translator->trans('Configuración actualizada exitosamente', [], 'Modules.Customuserdiscounts.Admin')
            );
            
            return $this->redirectToRoute('admin_custom_user_discounts_configure');
        }

        return $this->render('@Modules/customuserdiscounts/views/templates/admin/configure.html.twig', [
            'configurationForm' => $form->createView(),
            'help_link' => false,
            'enableSidebar' => true,
            'layoutTitle' => $this->translator->trans('Configuración de Descuentos Personalizados', [], 'Modules.Customuserdiscounts.Admin'),
        ]);
    }
}
