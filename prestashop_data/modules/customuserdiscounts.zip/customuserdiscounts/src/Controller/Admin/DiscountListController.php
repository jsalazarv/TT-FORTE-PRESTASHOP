<?php

namespace PrestaShop\Module\CustomUserDiscounts\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class DiscountListController extends FrameworkBundleAdminController
{
    public function indexAction(Request $request)
    {
        $repository = $this->get('prestashop.module.customuserdiscounts.repository.discount_repository');
        $discounts = $repository->findAll();

        return $this->render('@Modules/customuserdiscounts/views/templates/admin/discount_list.html.twig', [
            'discounts' => $discounts,
            'layoutTitle' => $this->trans('Customer Discounts', 'Modules.Customuserdiscounts.Admin'),
            'enableSidebar' => true,
            'help_link' => false
        ]);
    }

    public function deleteAction(Request $request, $discountId)
    {
        $repository = $this->get('prestashop.module.customuserdiscounts.repository.discount_repository');
        
        try {
            $repository->delete((int) $discountId);
            $this->addFlash('success', $this->trans('Discount successfully deleted.', 'Modules.Customuserdiscounts.Admin'));
        } catch (\Exception $e) {
            $this->addFlash('error', $this->trans('Error deleting discount.', 'Modules.Customuserdiscounts.Admin'));
        }

        return $this->redirectToRoute('admin_custom_user_discounts_list');
    }
}
