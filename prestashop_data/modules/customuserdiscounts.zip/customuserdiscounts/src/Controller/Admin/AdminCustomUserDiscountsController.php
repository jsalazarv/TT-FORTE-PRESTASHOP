<?php

namespace PrestaShop\Module\CustomUserDiscounts\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;

class AdminCustomUserDiscountsController extends FrameworkBundleAdminController
{
    public function listAction()
    {
        $discountRepository = $this->get('prestashop.module.customuserdiscounts.repository.discount_repository');
        $discounts = $discountRepository->findAll();

        return $this->render('@Modules/customuserdiscounts/views/templates/admin/list.tpl', [
            'discounts' => $discounts,
            'layoutTitle' => $this->trans('Customer Discounts', 'Modules.Customuserdiscounts.Admin'),
            'layoutHeaderToolbarBtn' => []
        ]);
    }

    public function deleteAction(Request $request)
    {
        $discountId = (int) $request->request->get('id_discount');

        if (!$discountId) {
            return new JsonResponse([
                'success' => false,
                'message' => $this->trans('Invalid discount ID', 'Modules.Customuserdiscounts.Admin')
            ]);
        }

        try {
            $discountRepository = $this->get('prestashop.module.customuserdiscounts.repository.discount_repository');
            $result = $discountRepository->delete($discountId);

            return new JsonResponse([
                'success' => $result,
                'message' => $result
                    ? $this->trans('Discount successfully deleted', 'Modules.Customuserdiscounts.Admin')
                    : $this->trans('Error deleting discount', 'Modules.Customuserdiscounts.Admin')
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'message' => $this->trans('Error deleting discount', 'Modules.Customuserdiscounts.Admin')
            ]);
        }
    }

    public function updateAction(Request $request)
    {
        $discountId = (int) $request->request->get('id_discount');
        $discountType = $request->request->get('discount_type');
        $discountValue = (float) $request->request->get('discount_value');

        if (!$discountId || !$discountType || $discountValue <= 0) {
            return new JsonResponse([
                'success' => false,
                'message' => $this->trans('Invalid discount data', 'Modules.Customuserdiscounts.Admin')
            ]);
        }

        try {
            $discountRepository = $this->get('prestashop.module.customuserdiscounts.repository.discount_repository');
            $result = $discountRepository->update($discountId, [
                'discount_type' => pSQL($discountType),
                'discount_value' => $discountValue
            ]);

            return new JsonResponse([
                'success' => $result,
                'message' => $result
                    ? $this->trans('Discount successfully updated', 'Modules.Customuserdiscounts.Admin')
                    : $this->trans('Error updating discount', 'Modules.Customuserdiscounts.Admin')
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'message' => $this->trans('Error updating discount', 'Modules.Customuserdiscounts.Admin')
            ]);
        }
    }
}
